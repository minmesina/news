<?php
	require('include/connection.php');
	$id=$_GET['id'];
	$sql = mysqli_query($con,"SELECT * FROM news where ID=$id");
	$data = mysqli_fetch_assoc($sql);

	$get_img=mysqli_query($con,"select * from background where bg_id=1")or die (mysqli_error());
	$bg_img=mysqli_fetch_assoc($get_img);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 	<link rel="stylesheet" type="text/css" href="style.css">
	<title><?php echo $data['Title']; ?></title>  
</head>
<body background="<?php echo 'uploaded/'.$bg_img['bg_name']; ?>">
	<a href="home.php">HOME</a>

	<article class="art">
	<h1 class="title"><?php echo $data['Title']; ?></h1>
	<?php $images = explode(',',$data['image']); ?>
	<div class="img">
		<?php foreach ($images as $image):?>
			<img src="uploaded/<?php echo $image; ?>" width="100" height="100">
		<?php endforeach ?>
	</div>
	<p><?php echo $data['Article']; ?></p>
	</article>
</body>
</html>