<?php 
	$con = mysqli_connect("localhost","root","","web");
	if(!$con){
		die('Could not connect: ' . mysqli_error());
	}
?>