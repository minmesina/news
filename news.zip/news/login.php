<?php
	require('include/connection.php');
	if(isset($_POST['submit'])){
		$username=$_POST['username'];
		$password=$_POST['password'];

		$result=mysqli_query($con,"select * from account where username='$username' and password='$password'")or die (mysqli_error());
		$data=mysqli_fetch_assoc($result);
	
		if($data['username']=="admin"){	
			header('location:home.php');
		}else{
			header('location:index.php');
		}
	}
?>