<?php
	require('include/connection.php');
	$get_img=mysqli_query($con,"select * from background where bg_id=1")or die (mysqli_error());
	$bg_img=mysqli_fetch_assoc($get_img);

	$id=$_GET['id']; //kukunin yung id sa URL
?>
<!DOCTYPE html>
<html lang="en">
<head>
  	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  	<link rel="stylesheet" type="text/css" href="style.css">
  	<title>Upload Images</title>
</head>
<body background="<?php echo 'uploaded/'.$bg_img['bg_name']; ?>">
	<form method="post" action="" enctype="multipart/form-data">
		<input type="file" id="image" name="image[]" multiple="multiple">
		<input type="Submit" name="button" value="Upload">
	</form>

	<?php
		if(isset($_POST['button'])){
			if(count($_FILES['image']['name']) > 0){
        	for($i=0; $i<count($_FILES['image']['name']); $i++) {
            	$tmpFilePath = $_FILES['image']['tmp_name'][$i];
            	if($tmpFilePath != ""){
               		$shortname = $_FILES['image']['name'][$i];
                	$filePath = "uploaded/".$_FILES['image']['name'][$i];
                	if(move_uploaded_file($tmpFilePath, $filePath)){
                    	$files[] = $shortname;
            		}
              	}
        	}
    		}
		 	$uploaded=mysqli_query($con,"select image from news where ID=$id")or die (mysqli_error());
			$img=mysqli_fetch_assoc($uploaded);
			$imgs=$img['image'];

		    if(is_array($files)){
		    	$uploads = implode(',',$files);
		    }//implode gagawing string para mailagay sa database
		    
		    if($imgs!=''){
		    	$uploads=$imgs .','.$uploads;
		    }
				
			mysqli_query($con,"UPDATE news SET image='$uploads' WHERE ID='$id'") or die (mysqli_error());
			header("location:content.php?id=$id");
		} ?>
</body>
</html>