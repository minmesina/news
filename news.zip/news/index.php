<?php 
	require('include/connection.php');
	$get_img=mysqli_query($con,"select * from background where bg_id=1")or die (mysqli_error());
	$bg_img=mysqli_fetch_assoc($get_img);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="<?php echo 'uploaded/'.$bg_img['bg_name']; ?>">
	<form method="post" action="login.php"> 
		<label>Username:</label><input type="text" name="username"/>
		<label>Password:</label><input type="text" name="password"/>
		<input type="submit" name="submit" value="Login"/>
	</form>
</body>
</html>

