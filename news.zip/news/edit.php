<?php
	require('include/connection.php');
	$get_img=mysqli_query($con,"select * from background where bg_id=1")or die (mysqli_error());
	$bg_img=mysqli_fetch_assoc($get_img);

	$id=$_GET['id'];
	$sql = mysqli_query($con,"SELECT * FROM news where ID=$id");
	$data = mysqli_fetch_assoc($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  	<script src="tinymce/jquery-3.1.1.min"></script>
  	<link rel="stylesheet" type="text/css" href="style.css">
  	<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
  	<script>tinymce.init({ selector:'textarea' });</script>
</head>
<body background="<?php echo 'uploaded/'.$bg_img['bg_name']; ?>">
			<a href="home.php">HOME</a>
			<div class="managebutton">
				<a href="upload.php?id=<?php echo $data['ID']; ?>">ADD PHOTOS</a>
			</div>

			<?php $images = explode(',',$data['image']); ?>
			<div class="img">
			<?php foreach ($images as $image):?>
			<div class="manageimg">	
				<img src="uploaded/<?php echo $image; ?>" width="100" height="100">
				<form method="post" action="delete_img.php" enctype="multipart/form-data">
					<input type="hidden" name="id" value="<?php echo $data['ID']; ?>">
					<input type="hidden" name="img" value="<?php echo $image; ?>">
					<input type="Submit" name="delete" value="Delete">
				</form>
			</div>
			<?php endforeach ?>
			</div>
		
			<form method="post" action="" enctype="multipart/form-data">
				<label>Title: </label>
		   		<input type="text" name="Title" value="<?php echo $data['Title']; ?>">
				<textarea name="Article" class="tinymce" cols="30" rows="10"><?php echo $data['Article']; ?></textarea>
				<input type="Submit" name="button" value="Update information">
			</form>

		<?php
		if(isset($_POST['button'])){
			$Title=$_POST['Title'];
			$Article=$_POST['Article'];
			
			mysqli_query($con,"UPDATE news SET Title='$Title', Article='$Article' WHERE ID='$id'") or die (mysqli_error());

			header("location:content.php?id=$id");
		} ?>
</body>
</html>