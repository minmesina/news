<?php
	require('include/connection.php');
	$get_img=mysqli_query($con,"select * from background where bg_id=1")or die (mysqli_error());
	$bg_img=mysqli_fetch_assoc($get_img);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  	<script src="tinymce/jquery-3.1.1.min"></script>
  	<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
  	<script>tinymce.init({ selector:'textarea' });</script>
  	<link rel="stylesheet" type="text/css" href="style.css">

  <title>Create Article</title>
</head>
<body background="<?php echo 'uploaded/'.$bg_img['bg_name']; ?>">
	<a href="home.php">HOME</a>
	<form method="post" action="add.php" enctype="multipart/form-data">
	   	<input type="file" id="image" name="image[]" multiple="multiple"><br>
	   	<label>Title</label>
	  	<input type="text" name="Title" placeholder="Title">
		<textarea name="Article" class="tinymce" cols="30" rows="10"></textarea>
		<input type="Submit" name="button" value="Enter information">	
	</form>
	<div class="managebg">
		<form method="post" action="" enctype="multipart/form-data">
		   	<input type="file" id="bg" name="bg">
			<input type="Submit" name="save_bg" value="Change Background">	
		</form>
	</div>

	<?php // upload ng backgroung image
		if(isset($_POST['save_bg'])){
		$tmpFilePath = $_FILES['bg']['tmp_name'];
            if($tmpFilePath != ""){
                $img = $_FILES['bg']['name'];
                $filePath = "uploaded/".$_FILES['bg']['name'];

                if(move_uploaded_file($tmpFilePath, $filePath)) {
                    $check=mysqli_query($con,"select * from background")or die (mysqli_error());
                    $count = mysqli_num_rows($check);
                    if($count!=0){
                   		mysqli_query($con,"UPDATE background SET bg_name='$img' WHERE bg_id=1");
               		}else{
               			mysqli_query($con,"INSERT INTO background (bg_name) VALUES ('$img')");
               		}
				}
            }
			header('location:create_article.php');
		}
    ?>
</body>
</html>