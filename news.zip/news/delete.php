<?php
	require('include/connection.php');

	$id=$_GET['id']; //kukunin yung id sa URL
 	$sql = mysqli_query($con,"SELECT image FROM news where ID=$id");
	$data = mysqli_fetch_assoc($sql);

	$image_array = explode(',',$data['image']);
	foreach ($image_array as $image) {
	  	unlink("uploaded/".$image);
	}

	$sql = mysqli_query($con,"DELETE FROM news where ID=$id") or die (mysqli_error());
	$data = mysqli_fetch_assoc($sql);
	header("location:home.php");
?>