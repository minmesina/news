<?php
	require('include/connection.php');
	$get_img=mysqli_query($con,"select * from background where bg_id=1")or die (mysqli_error());
	$bg_img=mysqli_fetch_assoc($get_img);

	function trunc($article, $max_words) {
   		$article_array = explode(' ',$article);
   		if(count($article_array) > $max_words && $max_words > 0){
      		$summary = implode(' ',array_slice($article_array, 0, $max_words)).'...';
   		}else{
   	 		$summary = implode(' ',$article_array);
   		}
   		return $summary;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 	<link rel="stylesheet" type="text/css" href="style.css">
 	<title>News PHP</title>
</head>
<body background="<?php echo 'uploaded/'.$bg_img['bg_name']; ?>">
	<a href="create_article.php">Create Article</a>
<?php
	$result = mysqli_query($con,"SELECT * FROM news");
	while($row = mysqli_fetch_array($result)){  
	$images = explode(',',$row['image']);
?>
	<article class="art">
		<h1 class="title"><a href="content.php?id=<?php echo $row['ID']?>"><?php echo $row['Title']?></a></h1>
		<div class="managebutton">
			<a href="edit.php?id=<?php echo $row['ID']?>">Edit</a>
			<a href="delete.php?id=<?php echo $row['ID']?>">Delete</a>
		</div>
		<div class="img">
		<?php foreach ($images as $image):?>
			<img src="uploaded/<?php echo $image; ?>" width="100" height="100">
		<?php endforeach ?>
		</div>  
		<p><?php echo trunc($row['Article'],50); ?></p>
	</article>
	<hr>
	<?php } ?>
</body>
</html>