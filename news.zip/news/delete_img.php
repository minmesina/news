<?php
	require('include/connection.php');
	$id=$_POST['id'];
	$img=$_POST['img'];  

	$sql = mysqli_query($con,"SELECT image FROM news where ID=$id");
	$data = mysqli_fetch_assoc($sql);
	  
	$image_array = explode(',',$data['image']);
	$pos = array_search("$img", $image_array);
	unset($image_array[$pos]);

  	unlink("uploaded/".$img);
  	$uploads= implode(',',$image_array);
	mysqli_query($con,"UPDATE news SET image='$uploads' WHERE ID='$id'") or die (mysqli_error());

	header("location:content.php?id=$id");	
?>