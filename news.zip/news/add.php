<?php
	require('include/connection.php');
	if(count($_FILES['image']['name']) > 0){
        for($i=0; $i<count($_FILES['image']['name']); $i++) {
            $tmpFilePath = $_FILES['image']['tmp_name'][$i];
            if($tmpFilePath != ""){
                $shortname = $_FILES['image']['name'][$i];
                $filePath = "uploaded/".$_FILES['image']['name'][$i];
                if(move_uploaded_file($tmpFilePath, $filePath)) {
                    $files[] = $shortname;
                }
            }
        }
    }

    if(is_array($files)){
       $uploads= implode(',',$files);
    }

	$Title=$_POST['Title'];
	$Article=$_POST['Article'];
		
	if (!mysqli_query($con,"INSERT INTO news (Title, Article, image) VALUES ('$Title','$Article', '$uploads')")){
		die('Error querying database' . mysqli_error());
	}
	header('location:home.php');
?>	